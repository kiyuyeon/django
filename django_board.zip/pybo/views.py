from django.shortcuts import render,redirect,HttpResponse
from .forms import ArticleForm
from .models import User,Question,Answer

from django.views.decorators.csrf import csrf_exempt


# Create your views here.

def test(request):
    return HttpResponse('<h1>Ai12기 테스트 </h1>')

def question_list(requst):
    questionlist = Question.objects.all()
    return render(requst,'question_list.html',{'qlist':questionlist})


@csrf_exempt
def question_create(request): 
    if request.method == 'GET':
        form =ArticleForm()
        context={
            'form':form
        }
        return render(request,'question_create.html', context)
    elif request.method =='POST':
        form =ArticleForm(request.POST)
        if form.is_valid():
            question =form.save()
            return redirect('board')
